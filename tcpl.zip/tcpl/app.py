from python import app
app.secret_key = 'yourlove'
if __name__ == "__main__":
    app.run(debug=True)
