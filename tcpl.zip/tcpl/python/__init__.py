# your_flask_app/__init__.py

from flask import Flask
import flask

# Create the Flask application instance
app = Flask(__name__)

# Import routes from the routes module
from python import routes