from flask import Flask, render_template, request, redirect, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import mysql.connector

app = Flask(__name__)
app.secret_key = 'your_love'
import mysql.connector

try:
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="gestion_examens"
    )
    print("Connexion réussie à la base de données.")
except mysql.connector.Error as err:
    print(f"Erreur de connexion : {err}")

@app.route('/inscription', methods=['GET', 'POST'])
def inscription():
    if request.method == 'POST':
        nom_complet = request.form['name']
        email = request.form['email']
        mot_de_passe = request.form['password']
        confirm_password = request.form['confirm-password']
        role = request.form['role']

        if mot_de_passe != confirm_password:
            flash("Les mots de passe ne correspondent pas.", "danger")
            return redirect('/inscription')

        mot_de_passe_hash = generate_password_hash(mot_de_passe)

        cursor = db.cursor()
        cursor.execute("SELECT * FROM utilisateurs WHERE email = %s", (email,))
        utilisateur_exist = cursor.fetchone()

        if utilisateur_exist:
            flash("Cet email est déjà utilisé.", "danger")
            return redirect('/inscription')

        sql = "INSERT INTO utilisateurs (nom_complet, email, mot_de_passe, role) VALUES (%s, %s, %s, %s)"
        cursor.execute(sql, (nom_complet, email, mot_de_passe_hash, role))
        db.commit()
        cursor.close()

        flash("Inscription réussie ! Vous pouvez maintenant vous connecter.", "success")
        return redirect('/connexion')

    return render_template('inscription.html')

@app.route('/connexion', methods=['GET', 'POST'])
def connexion():
    if request.method == 'POST':
        email = request.form['username']
        mot_de_passe = request.form['password']

        cursor = db.cursor()
        cursor.execute("SELECT * FROM utilisateurs WHERE email = %s", (email,))
        utilisateur = cursor.fetchone()

        if utilisateur and check_password_hash(utilisateur[3], mot_de_passe):
            session['id'] = utilisateur[0]
            session['role'] = utilisateur[4]
            flash("Connexion réussie !", "success")
            return redirect('/')
        else:
            flash("Email ou mot de passe incorrect.", "danger")
            return redirect('/connexion')

    return render_template('connexion.html')

@app.route('/')
def index():
    if 'id' not in session:
        return redirect('/connexion')
    return render_template('accueil.html')

@app.route('/deconnexion')
def deconnexion():
    session.pop('id', None)
    session.pop('role', None)
    flash("Vous avez été déconnecté.", "success")
    return redirect('/connexion')
